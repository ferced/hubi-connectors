# HUBI para ChatGPT y Codex

La skill, los manifests y el contrato exportado del paquete se distribuyen bajo MIT (copyright 2026 Ferced Labs). Consultá `LICENSE` y `LICENSE-SCOPE.md` para el texto y su alcance; esta concesión no incluye iconos, marcas, servicio, hub ni firmware.

Vinculá HUBI mediante OAuth y pedí leer tus pantallas, diseñar una propuesta o crear un recordatorio. La skill hubi lee el contrato del hub y revisa una simulación antes de solicitar aplicación. Con ask, Aplicar exige aprobación humana en el panel; auto conserva su política local.

El paquete declara cliente OAuth provided y permisos hubi.read hubi.authoring hubi.signals. El secreto del cliente se configura sólo en el portal; los secretos de proveedores permanecen en el hub. hubi.control exige solicitud explícita, nuevo consentimiento y permiso local adicional. Una simulación no acredita recepción del dispositivo.

La vista MCP Apps se sirve desde el servidor por el recurso versionado indicado en la herramienta de render. Se conserva ui://hubi/screen-preview.html como alias de compatibilidad. Este paquete no despliega la UI ni el hub. Vinculaciones y revocaciones: /connectors. Consultá los enlaces públicos del editor incluidos en el manifest.
